<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Owner bank account</h2>
    </x-slot>

    @include('owner-transfers.styles')
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            @if(session('success'))
                <div role="status" class="rounded-lg bg-green-50 p-4 text-sm text-green-800">{{ session('success') }}</div>
            @endif

            @if($errors->any())
                <div role="alert" class="rounded-lg p-4" style="background:#fff1f2;color:#b91c1c;">
                    @foreach($errors->all() as $error)<p>{{ $error }}</p>@endforeach
                </div>
            @endif
            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <div class="flex flex-wrap justify-between gap-4 mb-6">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Transfer hand cash</h3>
                        <p class="mt-1 text-sm text-gray-600">Record cash deposited into the Owner bank account. This reduces cash in hand without recording an expense or changing profit. Returns bring cash back into hand and reduce the net transfer. The owner's bank balance and subsequent spending are not tracked.</p>
                    </div>
                    <div>
                        <div class="text-sm text-gray-500">Cash in hand today</div>
                        <div class="text-xl font-bold text-gray-900">Rs {{ number_format($cashInHand, 2) }}</div>
                    </div>
                </div>

                @php($createValue = fn ($field, $fallback = null) => old('action_key', 'create') === 'create' ? old($field, $fallback) : $fallback)
                <form method="POST" action="{{ route('owner-transfers.store') }}" class="space-y-4" x-data="{ saving: false }" @submit="saving = true">
                    @csrf
                    <input type="hidden" name="action_key" value="create">
                    <input type="hidden" name="submission_id" value="{{ $createValue('submission_id', $submissionId) }}">
                    <x-input-error :messages="$errors->get('submission_id')" />
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <x-input-label for="transferred_at" value="Transfer date" />
                            <x-text-input id="transferred_at" name="transferred_at" type="date" class="mt-1 block w-full" :value="$createValue('transferred_at', now()->toDateString())" :max="now()->toDateString()" required />
                            <x-input-error :messages="$errors->get('transferred_at')" class="mt-2" />
                        </div>
                        <div>
                            <x-input-label for="amount" value="Amount (Rs)" />
                            <x-text-input id="amount" name="amount" type="number" min="0.01" max="9999999999.99" step="0.01" class="mt-1 block w-full" :value="$createValue('amount')" required />
                            <x-input-error :messages="$errors->get('amount')" class="mt-2" />
                        </div>
                        <div>
                            <x-input-label for="destination" value="Owner bank / account" />
                            <x-text-input id="destination" name="destination" type="text" maxlength="190" :value="$createValue('destination', 'Owner bank account')" class="mt-1 block w-full" />
                            <p class="mt-1 text-xs text-gray-500">Enter the bank and account name or last digits to identify the destination in the ledger.</p>
                        </div>
                        <div>
                            <x-input-label for="reference" value="Deposit reference (optional)" />
                            <x-text-input id="reference" name="reference" type="text" maxlength="120" class="mt-1 block w-full" :value="$createValue('reference')" />
                            <x-input-error :messages="$errors->get('reference')" class="mt-2" />
                        </div>
                    </div>
                    <div>
                        <x-input-label for="notes" value="Notes (optional)" />
                        <textarea id="notes" name="notes" maxlength="2000" rows="2" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">{{ $createValue('notes') }}</textarea>
                        <x-input-error :messages="$errors->get('notes')" class="mt-2" />
                    </div>
                    <x-primary-button x-bind:disabled="saving" x-text="saving ? 'Saving…' : 'Record transfer'">Record transfer</x-primary-button>
                </form>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Transfers to Owner bank account</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm divide-y divide-gray-200 owner-transfer-table">
                        <thead class="bg-gray-50"><tr>
                            <th class="px-4 py-3 text-left">Date / reference</th>
                            <th class="px-4 py-3 text-left">Destination / notes</th>
                            <th class="px-4 py-3 text-right">Transferred (Rs)</th>
                            <th class="px-4 py-3 text-right">Returned (Rs)</th>
                            <th class="px-4 py-3 text-right">Net transferred (Rs)</th>
                            <th class="px-4 py-3 text-left">Actions</th>
                        </tr></thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse($transfers as $transfer)
                                <tr class="{{ $transfer->deleted_at ? 'owner-transfer-deleted' : '' }}">
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <div>{{ $transfer->transferred_at->format('Y-m-d') }}</div>
                                        <div class="text-xs">{{ $transfer->reference ?: 'OT-'.$transfer->id }}</div>
                                        <div class="text-xs text-gray-500">{{ $transfer->creator?->name ?? '—' }}</div>
                                    </td>
                                    <td class="px-4 py-3" style="min-width:180px;">
                                        <div class="font-semibold">{{ $transfer->destination }}</div><div>{{ $transfer->notes }}</div>
                                        @if($transfer->deleted_at)
                                            <strong>Deleted</strong><div>Reason: {{ $transfer->deletion_reason }}</div>
                                            <div class="text-xs">{{ $transfer->deleter?->name ?? '—' }} · {{ $transfer->deleted_at->format('Y-m-d H:i') }}</div>
                                        @endif
                                    </td>
                                    <td class="px-4 py-3 text-right font-mono {{ $transfer->deleted_at ? '' : 'owner-transfer-sent' }}">{{ number_format($transfer->amount, 2) }}</td>
                                    <td class="px-4 py-3 text-right font-mono {{ $transfer->deleted_at ? '' : 'owner-transfer-returned' }}">{{ number_format($transfer->returned_amount, 2) }}</td>
                                    <td class="px-4 py-3 text-right font-mono font-semibold {{ $transfer->deleted_at ? '' : 'owner-transfer-sent' }}">{{ number_format($transfer->net_amount, 2) }}</td>
                                    <td class="px-4 py-3">
                                        @if(!$transfer->deleted_at)
                                            <div class="flex flex-wrap gap-2">
                                                <button type="button" class="owner-transfer-button" data-transfer-dialog="edit-transfer-{{ $transfer->id }}">Edit</button>
                                                @if($transfer->net_amount > 0)
                                                    <button type="button" class="owner-transfer-button owner-transfer-returned" data-transfer-dialog="return-transfer-{{ $transfer->id }}">Return amount</button>
                                                @endif
                                                <button type="button" class="owner-transfer-button" style="color:#b91c1c;" data-transfer-dialog="delete-transfer-{{ $transfer->id }}">Delete</button>
                                            </div>
                                        @else
                                            <span>Excluded from balances</span>
                                        @endif
                                    </td>
                                </tr>
                                @foreach($transfer->returns as $return)
                                    <tr class="{{ $transfer->deleted_at ? 'owner-transfer-deleted' : 'owner-transfer-returned' }}">
                                        <td class="px-4 py-3">{{ $return->returned_at->format('Y-m-d') }}<div class="text-xs">OTR-{{ $return->id }}</div></td>
                                        <td colspan="2" class="px-4 py-3"><strong>Return from OT-{{ $transfer->id }}</strong><div>{{ $return->notes }}</div><div class="text-xs">{{ $return->creator?->name ?? '—' }}{{ $transfer->deleted_at ? ' · Deleted with transfer' : '' }}</div></td>
                                        <td class="px-4 py-3 text-right font-mono">{{ number_format($return->amount, 2) }}</td>
                                        <td colspan="2" class="px-4 py-3 text-xs">{{ $transfer->deleted_at ? 'Excluded from balances' : 'Cash returned to hand' }}</td>
                                    </tr>
                                @endforeach
                            @empty
                                <tr><td colspan="6" class="px-4 py-6 text-gray-500">No owner transfers recorded yet.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                @foreach($transfers as $transfer)
                    @if(!$transfer->deleted_at)
                        @include('owner-transfers.dialogs')
                    @endif
                @endforeach
                <div class="mt-4">{{ $transfers->links() }}</div>
            </div>
        </div>
    </div>
    @once
        <script src="{{ asset('js/owner-transfers.js') }}?v={{ is_file(public_path('js/owner-transfers.js')) ? filemtime(public_path('js/owner-transfers.js')) : '1' }}" defer></script>
    @endonce
</x-app-layout>
