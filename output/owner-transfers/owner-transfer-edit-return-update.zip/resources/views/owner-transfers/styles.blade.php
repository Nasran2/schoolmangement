<style>
    .owner-transfer-sent { background:#eef2ff; color:#3730a3; }
    .owner-transfer-returned { background:#ecfdf5; color:#065f46; }
    .owner-transfer-deleted, .owner-transfer-deleted td { background:#fff1f2; color:#b91c1c; }
    .owner-transfer-button { display:inline-flex; align-items:center; border:1px solid #cbd5e1; border-radius:6px; padding:6px 10px; font-size:13px; background-color:#fff; white-space:nowrap; }
    .owner-transfer-button:focus-visible { outline:2px solid #4f46e5; outline-offset:2px; }
    .owner-transfer-dialog { border:0; border-radius:12px; width:calc(100% - 32px); max-width:520px; max-height:90vh; padding:24px; overflow:auto; box-shadow:0 20px 60px #0003; }
    .owner-transfer-dialog::backdrop { background:#0f172a80; }
    .owner-transfer-dialog input, .owner-transfer-dialog textarea { width:100%; margin-top:4px; border:1px solid #d1d5db; border-radius:6px; }
    .owner-transfer-dialog label { display:block; font-size:14px; color:#374151; }
    .owner-transfer-dialog form > div { margin-top:16px; }
    .owner-transfer-dialog-header { display:flex; align-items:center; justify-content:space-between; gap:16px; }
    .owner-transfer-dialog-header h3 { font-size:20px; font-weight:600; }
    .owner-transfer-dialog-actions { display:flex; justify-content:flex-end; gap:12px; flex-wrap:wrap; }
</style>
