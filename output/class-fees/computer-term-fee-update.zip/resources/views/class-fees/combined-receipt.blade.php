@php
    $primary = $bundleItems->first();
    $active = $bundleItems->reject(fn ($line) => $line->isCancelled() || $line->payment_status === 'rejected');
    $pending = $active->whereIn('payment_status', ['hold', 'pending'])->isNotEmpty();
    $cancelled = $active->count() !== $bundleItems->count();
    $total = (float) $active->sum('amount');
    $refunded = (float) $bundleItems->sum(fn ($line) => $line->adjustments->where('type', 'refund')->sum('amount'));
    $net = (float) $active->whereNotIn('payment_status', ['hold', 'pending'])->sum('amount') - $refunded;
@endphp
<x-app-layout>
    <x-slot name="header"><div class="flex flex-wrap items-center justify-between gap-3"><h2 class="text-xl font-semibold">Exam &amp; Computer Fee Receipt</h2><div class="flex gap-4"><a class="text-indigo-700 underline" href="{{ route('revenue.items.create', ['quick' => 'exam', 'student_id' => $primary->student_id]) }}">Back to fee collection</a><button type="button" class="rounded-md bg-indigo-600 px-4 py-2 text-white" onclick="window.print()">Print Receipt</button></div></div></x-slot>
    <style>
        .combined-fee-receipt { max-width:850px; margin:24px auto; padding:28px; border:1px solid #e2e8f0; border-radius:12px; background:white; color:#1e293b; }
        .combined-fee-receipt h1 { font-size:22px; font-weight:700; }.combined-fee-receipt p { margin:5px 0; font-size:13px; }
        .combined-fee-receipt table { width:100%; border-collapse:collapse; margin:22px 0; font-size:13px; }.combined-fee-receipt td,.combined-fee-receipt th { text-align:left; padding:12px 8px; border-bottom:1px solid #e2e8f0; vertical-align:top; }.combined-fee-receipt th { background:#f8fafc; }.combined-fee-receipt small { color:#64748b; }.combined-fee-receipt .money { text-align:right; white-space:nowrap; }.combined-fee-receipt .state { padding:12px; border:1px solid #c7d2fe; background:#eef2ff; border-radius:7px; margin:16px 0; }.combined-fee-receipt .total { text-align:right; font-size:20px; font-weight:700; }.combined-fee-receipt .cancelled { color:#b91c1c; background:#fff1f2; }
        @media print { body * { visibility:hidden; }.combined-fee-receipt,.combined-fee-receipt * { visibility:visible; }.combined-fee-receipt { position:absolute; left:0; top:0; width:100%; max-width:none; margin:0; border:0; padding:16px; } }
    </style>
    <article class="combined-fee-receipt">
        @if($schoolLogoDataUri)<img src="{{ $schoolLogoDataUri }}" alt="School logo" style="max-width:70px;max-height:70px;margin-bottom:12px;">@endif
        <h1>{{ $schoolInfo['name'] }}</h1><p>{{ $schoolInfo['address'] }}</p><p>{{ $schoolInfo['phone'] }} {{ $schoolInfo['email'] }}</p>
        <div class="state">{{ $active->isEmpty() ? 'Payment cancelled / returned' : ($pending ? 'Payment Pending Confirmation — CHEQUE PENDING' : ($cancelled ? 'Updated receipt — includes cancelled components' : 'Payment Successful!')) }}</div>
        <p><strong>Bill number:</strong> {{ $primary->payment_meta['fee_bundle']['bill_no'] }}</p>
        <p><strong>Student:</strong> {{ $primary->student?->name }} · {{ $primary->student?->admission_number }}</p>
        <p><strong>Payment method:</strong> {{ ['cash' => 'Cash', 'bank_transfer' => 'Bank Transfer', 'cheque' => 'Cheque'][$primary->payment_method] ?? $primary->payment_method }}</p>
        @if(in_array($primary->payment_method, ['bank_transfer', 'cheque'], true))<p><strong>Bank:</strong> {{ $primary->payment_meta['bank'] ?? '—' }} · <strong>Reference / cheque:</strong> {{ $primary->payment_meta['ref_no'] ?? $primary->payment_meta['cheque_number'] ?? '—' }}@if($primary->cheque_date) · <strong>Cheque date:</strong> {{ $primary->cheque_date->format('d-m-Y') }}@endif</p>@endif
        <table><thead><tr><th>Fee / term paid</th><th>Payment date</th><th>Status</th><th class="money">Amount (Rs)</th></tr></thead><tbody>
            @foreach($bundleItems as $line)
                @php($invalid = $line->isCancelled() || $line->payment_status === 'rejected')
                <tr class="{{ $invalid ? 'cancelled' : '' }}"><td><strong>{{ $line->category?->name }}</strong><br>{{ $line->exam_term_label }} · {{ $line->classFeeSchedule?->classRoom?->name }}<br><small>Accounting reference: {{ $line->bill_no }}</small>@if($line->cancel_reason)<br><small>Reason: {{ $line->cancel_reason }}</small>@endif</td><td>{{ $line->paid_at->format('d-m-Y') }}</td><td>{{ $line->isCancelled() ? 'Cancelled' : ($line->payment_status === 'rejected' ? 'Cheque returned' : (in_array($line->payment_status, ['hold', 'pending'], true) ? 'Pending cheque' : 'Paid')) }}</td><td class="money">{{ number_format($invalid ? 0 : $line->amount, 2) }}</td></tr>
            @endforeach
        </tbody></table>
        <p class="total">Total: Rs {{ number_format($total, 2) }}</p>
        @if($refunded > 0)<p style="text-align:right;">Refunded: Rs {{ number_format($refunded, 2) }}</p>@endif
        <p style="text-align:right;">{{ $pending ? 'Collected after clearance' : 'Net collected' }}: Rs {{ number_format(max(0, $net), 2) }}</p>
        <p style="margin-top:28px;">Authorized signature / cashier ____________________</p>
        <p><small>Exam and computer fees are recorded separately under this combined bill. This is a computer-generated receipt.</small></p>
    </article>
    @if($autoPrint)<script>window.addEventListener('load', () => window.print());</script>@endif
</x-app-layout>
